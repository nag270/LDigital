package org.test.restcrud.service;
 
import java.util.List;
 
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
 
import org.test.restcrud.dao.userdao;
import org.test.restcrud.model.user;
 
@Path("/users")
public class userService {
 
    // URI:
    // /contextPath/servletPath/users
    @GET
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public List<user> getusers_JSON() {
        List<user> listOfCountries = userdao.getAllusers();
        return listOfCountries;
    }
 
    // URI:
    // /contextPath/servletPath/users/{userphone}
    @GET
    @Path("/{userphone}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public user getuser(@PathParam("userphone") String userphone) {
        return userdao.getuser(userphone);
    }
 
    // URI:
    // /contextPath/servletPath/users
    @POST
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public user adduser(user usr) {
        return userdao.adduser(usr);
    }
 
    // URI:
    // /contextPath/servletPath/users
    @PUT
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public user updateuser(user usr) {
        return userdao.updateuser(usr);
    }
 
    @DELETE
    @Path("/{userphone}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public void deleteuser(@PathParam("userphone") String userphone) {
        userdao.deleteuser(userphone);
    }
 
}
