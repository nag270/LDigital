package org.o7planning.restcrud.model;

import javax.xml.bind.annotation.XmlRootElement; 
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

 
@XmlRootElement(name = "user")
@XmlAccessorType(XmlAccessType.FIELD)
public class user {
 
    private String userphone;
    private String useremail;
    private String username;
 
    // This default constructor is required if there are other constructors.
    public user() {
 
    }
 
    public user(String userphone, String useremail, String username) {
        this.userphone = userphone;
        this.useremail = useremail;
        this.username = username;
    }
 
    public String getuserphone() {
        return userphone;
    }
 
    public void setuserphone(String userphone) {
        this.userphone = userphone;
    }
 
    public String getuseremail() {
        return useremail;
    }
 
    public void setuseremail(String useremail) {
        this.useremail = useremail;
    }
 
    public String getusername() {
        return username;
    }
 
    public void setusername(String username) {
        this.username = username;
    }
 }
