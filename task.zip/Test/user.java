package org.test.restcrud.user;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import org.test.restcrud.model.user;
 
public class user{
 
    private static final Map<String, user> usMap = new HashMap<String, user>();
 
    static {
        initus();
    }
 
    private static void initus() {
        user us1 = new user("9999988888", "abc", "abc@mail.com");
        user us2 = new user("5555544444", "man", "man@mail.com");
        user us3 = new user("2222233333", "xyz", "xyz@mail.com");
 
        usMap.put(us1.getusNo(), us1);
        usMap.put(us2.getusNo(), us2);
        usMap.put(us3.getusNo(), us3);
    }
 
    public static user getuser(String usNo) {
        return usMap.get(usNo);
    }
 
    public static user adduser(user us) {
        usMap.put(us.getusNo(), us);
        return us;
    }
 
    public static user updateuser(user us) {
        usMap.put(us.getusNo(), us);
        return us;
    }
 
    public static void deleteuser(String usNo) {
        usMap.remove(usNo);
    }
 
    public static List<user> getAllusers() {
        Collection<user> c = usMap.values();
        List<user> list = new ArrayList<user>();
        list.addAll(c);
        return list;
    }
     
    List<user> list;
 
}